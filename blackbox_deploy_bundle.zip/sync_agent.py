def sync_to_gsheet(data, sheet_id=None):
    return "Sync to Google Sheets not implemented yet"

def sync_to_openai_agent(data):
    return "Data synced to Builder Agent"
