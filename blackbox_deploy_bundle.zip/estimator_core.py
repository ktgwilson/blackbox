def estimate_project(scope, region="default"):
    """
    Core logic to estimate labor, materials, per diem, and tools
    based on scope input.
    """
    results = {
        "crew_required": 2,
        "duration_days": 3,
        "tools": ["dolly", "impact drill", "ladder"],
        "materials": ["mounting brackets", "hardware"],
        "daily_per_diem": 120,
        "region_modifier": 1.0,
        "estimated_total": 3200
    }
    return results
