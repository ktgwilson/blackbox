import json

def export_json(estimate_data, filename="estimate_output.json"):
    with open(filename, "w") as f:
        json.dump(estimate_data, f, indent=4)
    return f"Estimate exported to {filename}"
